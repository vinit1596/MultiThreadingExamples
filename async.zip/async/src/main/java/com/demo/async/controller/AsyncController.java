package com.demo.async.controller;

import java.util.Calendar;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.demo.async.service.AsyncService;
import com.demo.async.service.CompletableFutureService;

@Controller
public class AsyncController {

	@Autowired
	AsyncService asyncService;
	
	@Autowired
	CompletableFutureService completableFutureService;
	
	@GetMapping("/asyncCheckBooks")
	public ResponseEntity<?> getBooks(){
		
		System.out.println("Inside Async Controller");
		System.out.println("Before Service Call:"+Calendar.getInstance().getTime());
		
		for(int i=0;i<5;i++)
			asyncService.getBooksService();
		
		System.out.println("After Service Call:"+Calendar.getInstance().getTime());
		return new ResponseEntity<String>("", HttpStatus.OK);
	}
	
	
	@GetMapping("/completableFutureAsyncCheckBooks")
	public ResponseEntity<?> getBooksCompletableFuture(){
		
		System.out.println("Inside CompletableFuture Controller");
		System.out.println("Before Service Call:"+Calendar.getInstance().getTime());
		
		CompletableFuture<String> completableFuture1 = completableFutureService.getBooks();
		CompletableFuture<String> completableFuture2 = completableFutureService.getBooks();
		CompletableFuture<String> completableFuture3 = completableFutureService.getBooks();
		CompletableFuture<String> completableFuture4 = completableFutureService.getBooks();
		
		CompletableFuture<Void> completableFutureCombined = CompletableFuture.allOf(completableFuture1,completableFuture2,completableFuture3,completableFuture4);
		completableFutureCombined.join();
		
		System.out.println("After Service Call:"+Calendar.getInstance().getTime());
		return new ResponseEntity<String>("", HttpStatus.OK);
	}
	
}
