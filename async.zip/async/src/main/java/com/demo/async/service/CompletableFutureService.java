package com.demo.async.service;

import java.util.Calendar;
import java.util.concurrent.CompletableFuture;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class CompletableFutureService {

	@Async
	public CompletableFuture<String> getBooks() {
		System.out.println("CompletableFutureService Before thread sleep:"+Calendar.getInstance().getTime());
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("CompletableFutureService After thread sleep:"+Calendar.getInstance().getTime());
		
		CompletableFuture<String> completableFuture = new CompletableFuture<String>();
		completableFuture.complete("books");
		
		return completableFuture;
	}
	
}
