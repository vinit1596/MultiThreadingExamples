package com.example.util;

import java.util.concurrent.Executor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class AsyncConfiguration {
	private static final Logger LOGGER = LoggerFactory.getLogger(AsyncConfiguration.class);
	
	@Value("${threadpool.corepoolsize}")
    int corePoolSize;
     
    @Value("${threadpool.maxpoolsize}")
    int maxPoolSize;
    
    @Value("${threadpool.maxqueuecapacity}")
    int maxqueuecapacity;
	
	@Bean (name = "taskExecutor")
    public Executor taskExecutor() {
        LOGGER.info("Creating Async Task Executor");
        final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(maxqueuecapacity);
        //executor.setThreadNamePrefix("CarThread-");
        executor.initialize();
        return executor;
    }
	
}
