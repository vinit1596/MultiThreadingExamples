package com.example.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.completablefuture.CompletableFutureInt;
import com.example.entity.Users;
import com.example.repository.UserJpaRepository;
import com.example.repository.UserJpaRepositoryService;

@RestController
@RequestMapping(value = "/users")
public class UserController {

	@Autowired
	UserJpaRepository userJpaRepository;
	
	@Autowired
	UserJpaRepositoryService userJpaRepositoryService;
	
	@Autowired
	CompletableFutureInt completableFuture;
	
	@GetMapping(value = "/all")
	public List<Users> findAll(){
		return userJpaRepository.findAll();
	}
	
	/* @GetMapping(value = "/{name}") */
	//@RequestMapping(method = RequestMethod.GET)
	
	/*
	 * @GetMapping public Users findByName(@RequestParam(value="name") String name){
	 * return userJpaRepository.findByName(name); }
	 */
	 
		
	@GetMapping(value = "/getByName/{name}")
	public Users findByName(@PathVariable final String name) {
		return userJpaRepository.findByName(name);
	}
	 
	
	@PostMapping(value = "/load")
	public Users load(@RequestBody final Users users) {
		userJpaRepository.save(users);
		return userJpaRepository.findByName(users.getName());
	}
	
	@GetMapping(value = "/findByTeamName/{teamName}")
	public List<Users> findByTeamName(@PathVariable final String teamName) {
		return userJpaRepository.findByTeamName(teamName);
	}
	
	@GetMapping(value = "/findBySalary/{salary}")
	public List<Users> findBySalary(@PathVariable final String salary) {
		return userJpaRepositoryService.getListBySalary(Integer.parseInt(salary));
	}
	

	@PostMapping(value = "/loadAllCompletable")
	public List<Users> loadAllCompletable(@RequestBody final List<Users> users) throws InterruptedException, ExecutionException {
		System.out.println("Before:"+Calendar.getInstance().getTime()+"---"+Calendar.getInstance().getTimeInMillis());
		CompletableFuture<Void> completableFutureCombined=CompletableFuture.allOf();
		List<Users> userAdded = new ArrayList<Users>();
		for (Users user : users) {
			CompletableFuture<Users> completableFuture1 = completableFuture.addUserServiceCalleable(user);
			userAdded.add(completableFuture1.get());
			completableFutureCombined = CompletableFuture.allOf(completableFuture1);
			
		}
		completableFutureCombined.join();
		
		System.out.println("After :"+Calendar.getInstance().getTime()+"---"+Calendar.getInstance().getTimeInMillis());
		return userAdded;
	}
	
	
	@PostMapping(value = "/loadAll")
	public List<Users> loadAll(@RequestBody final List<Users> users) {
		System.out.println("Before:"+Calendar.getInstance().getTime()+"---"+Calendar.getInstance().getTimeInMillis());
		for (Users user : users) {
			completableFuture.addUserService(user);			
		}
		
		System.out.println("After :"+Calendar.getInstance().getTime()+"---"+Calendar.getInstance().getTimeInMillis());
		return users;
	}
	
}
