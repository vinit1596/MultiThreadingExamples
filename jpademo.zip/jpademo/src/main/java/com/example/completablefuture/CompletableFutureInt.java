package com.example.completablefuture;

import java.util.concurrent.CompletableFuture;

import com.example.entity.Users;

public interface CompletableFutureInt {

	public CompletableFuture<Users> addUserServiceCalleable(Users users);
	public void addUserService(Users user);
	
}
