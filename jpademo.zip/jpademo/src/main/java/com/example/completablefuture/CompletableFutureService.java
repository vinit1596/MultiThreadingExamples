package com.example.completablefuture;

import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.example.entity.Users;
import com.example.repository.UserJpaRepository;

@Service
public class CompletableFutureService implements CompletableFutureInt {

	@Autowired
	UserJpaRepository userJpaRepository;
	
	@Async
	public CompletableFuture<Users> addUserServiceCalleable(Users user) {
		CompletableFuture<Users> completableFuture = new CompletableFuture<Users>();
		userJpaRepository.save(user);
		completableFuture.complete(user);
		return completableFuture;
	}
	
	public void addUserService(Users user) {
		userJpaRepository.save(user);
	}
	
}
