package com.threadexample.springthreadpoolcalleableexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringthreadpoolcalleableexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
