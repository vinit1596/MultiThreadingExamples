package com.threadexample.springthreadpoolcalleableexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringthreadpoolcalleableexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringthreadpoolcalleableexampleApplication.class, args);
	}

}
